// **********************************************************************
// PUCRS/Escola Polit�cnica
// COMPUTA��O GR�FICA
//
// Programa basico para criar aplicacoes 2D em OpenGL
//
// Marcio Sarroglia Pinho
// pinho@pucrs.br
// **********************************************************************


// Para uso no Xcode:
// Abra o menu Product -> Scheme -> Edit Scheme -> Use custom working directory
// Selecione a pasta onde voce descompactou o ZIP que continha este arquivo.
//

#include <iostream>
#include <string>
#include <cmath>
#include <ctime>
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>
#include <EnemyShip.h>
#include <PlayerShip.h>
#include <ObjectModel.h>
#include <Position.h>
#include <ColorRGB.h>
#include <TextManager.h>
#include <unistd.h>

using namespace std;

#ifdef WIN32
#include <windows.h>
#include <glut.h>
static DWORD last_idle_time;
#else
#include <sys/time.h>
static struct timeval last_idle_time;
#endif

#ifdef __APPLE__
#include <GLUT/glut.h>
#endif

#ifdef __linux__
#include <glut.h>
#endif

enum State{MENU,INGAME,GAMEOVER};

// Vari�veis Globais
State state;
float deltaTime;
bool canProcess = false;
bool debug;
bool win;
int WIDTHSCREEN;
int HEIGHTSCREEN;
int ENEMYAMOUNT;
int ENEMYMODELS;
int BULLETMODELS;
int score;
int bestScore;
vector<ObjectModel*> enemysModels;
vector<ObjectModel*> bulletModels;
vector<ObjectModel*> numbers;
vector<ObjectModel*> letters;
vector<EnemyShip*> enemysList;
vector<ColorRGB*> colorsList;
vector<Bullet*> bulletsInGame;
ObjectModel* playerModel;
ObjectModel* heartModel;
PlayerShip* player;
ColorRGB* backgroundColor;
TextManager textManager;

// M�todos OpenGL
void animate();
void init(void);
void reshape( int w, int h );
void display( void );
void keyboard ( unsigned char key, int x, int y );
void arrow_keys ( int a_keys, int x, int y );

// M�todos do Jogo
void InitializeVariables();
void LoadColorsList();
void LoadObjectsModels();
void LoadModel(ObjectModel* _modelObj, char fileName[]);
void LoadConfig();
void LoadNumbersModels();
void LoadAlphabet();
void LoadBestScore();
void Process();
void VerifyUserActions();
void Draw();
void DrawGUI();
void DrawMenu();
void DrawGameOver();
void DrawScore();
void DrawWord(Text* _text);
void DrawNumber(int _number, Position* _pos, int _scale);
void DrawObject(Position* pos, ObjectModel* _model, float _angle, float _sizeCell);
void DrawQuad(int _ix, int _iy);
void Debug();
void Quit();
bool IsColliding(Object* obj1, Object* obj2);

// **********************************************************************
//  void animate ( unsigned char key, int x, int y )
// **********************************************************************
void animate()
{
    static float dt;
    static float AccumTime=0;

#ifdef _WIN32
    DWORD time_now;
    time_now = GetTickCount();
    dt = (float) (time_now - last_idle_time) / 1000.0;
#else
    // Figure out time elapsed since last call to idle function
    struct timeval time_now;
    gettimeofday(&time_now, NULL);
    dt = (float)(time_now.tv_sec  - last_idle_time.tv_sec) +
    1.0e-6*(time_now.tv_usec - last_idle_time.tv_usec);
#endif
    AccumTime +=dt;
    deltaTime = (dt < 1) ? dt:deltaTime;
    if (AccumTime >=3) // imprime o FPS a cada 3 segundos
    {
        cout << 1.0/dt << " FPS"<< endl;
        AccumTime = 0;
    }
    // cout << "AccumTime: " << AccumTime << endl;
    // Anima cubos
    //AngY++;
    // Salva o tempo para o pr�ximo ciclo de rendering
    last_idle_time = time_now;

    //if  (GetAsyncKeyState(32) & 0x8000) != 0)
    //  cout << "Espaco Pressionado" << endl;

    // Redesenha
    if((deltaTime < 1) & (deltaTime != 0)) canProcess = true;
    glutPostRedisplay();
}
// **********************************************************************
//  void init(void)
//  Inicializa os par�metros globais de OpenGL
// **********************************************************************
void init(void)
{
	// Define a cor do fundo da tela (PRETO)
    glClearColor(backgroundColor->r, backgroundColor->g, backgroundColor->b, 1.0f);

}

// **********************************************************************
//  void reshape( int w, int h )
//  trata o redimensionamento da janela OpenGL
// **********************************************************************
void reshape( int w, int h )
{
    // Reset the coordinate system before modifying
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    // Define a area a ser ocupada pela �rea OpenGL dentro da Janela
    glViewport(0, 0, w, h);

    // Define os limites l�gicos da �rea OpenGL dentro da Janela
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glOrtho(0,10,0,10,0,1);
}
// **********************************************************************
//  void display( void )
// **********************************************************************
void display( void )
{
	// Limpa a tela coma cor de fundo
	glClear(GL_COLOR_BUFFER_BIT);

    // Define os limites l�gicos da �rea OpenGL dentro da Janela
	glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    //glOrtho(-WIDTHSCREEN,WIDTHSCREEN,-HEIGHTSCREEN,HEIGHTSCREEN,0,1);
    glOrtho(0,WIDTHSCREEN,0,HEIGHTSCREEN,0,1);
	// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
	// Coloque aqui as chamadas das rotinas que desenha os objetos
	// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

    if(canProcess)
    {
        switch(state)
        {
            case MENU:
                DrawMenu();
                break;
            case INGAME:
                Process();
                Draw();
                break;
            case GAMEOVER:
                DrawGameOver();
                break;
        }
    }
	glutSwapBuffers();
}

// **********************************************************************
//  void keyboard ( unsigned char key, int x, int y )
// **********************************************************************
void keyboard ( unsigned char key, int x, int y )
{

	switch ( key )
	{
		case 27:
            Quit();
			break;
        case ' ':
            player->Shoot();
            break;
        case 'p':
            debug = !debug;
            break;
        case 's':
            if(state == MENU)
            {
                state = INGAME;
            }
            break;
        case 'r':
            if(state == GAMEOVER)
            {
                InitializeVariables();
                state = INGAME;
            }
            break;
		default:
			break;
	}
}

// **********************************************************************
//  void arrow_keys ( int a_keys, int x, int y )
// **********************************************************************
void arrow_keys ( int a_keys, int x, int y )
{
	switch ( a_keys )
	{
		case GLUT_KEY_UP:       // Se pressionar UP
			glutFullScreen ( ); // Vai para Full Screen
			break;
	    case GLUT_KEY_DOWN:     // Se pressionar UP
								// Reposiciona a janela
            glutPositionWindow (50,50);
			glutReshapeWindow ( 700, 500 );
			break;
		default:
			break;
	}
}
// **********************************************************************
//  void DrawMenu()
//  trata o redimensionamento da janela OpenGL
// **********************************************************************
void DrawMenu()
{
    DrawWord(textManager.title);
    DrawWord(textManager.start);
    DrawWord(textManager.name);
}
// **********************************************************************
//  LoadNumbersModels()
//  Carrega os modelos dos numeros
// **********************************************************************
void LoadNumbersModels()
{
    ifstream file;
    char fileName[10];
    ObjectModel* numberModel;

    for(int i=0; i<10; i++)
    {
        sprintf(fileName,"%d.txt",i);

        file.open(fileName);

        if(file == NULL)
        {
            printf("%d.txt n�o encontrado!\n",i);
            return;
        }

        numberModel = new ObjectModel();
        LoadModel(numberModel, fileName);
        numbers.push_back(numberModel);

        file.close();
    }
    printf("Numeros carregados com sucesso!\n");
}
// **********************************************************************
//  void DrawNumber(int _number, Position* _pos, int _scale)
//  Desenha o numero na localiza��o e escala informada
// **********************************************************************
void DrawNumber(int _number, Position* _pos, int _scale)
{
    ObjectModel* number;
    Position pos = *(_pos);

    if(_number == 0)
    {
        DrawObject(&pos, numbers.at(0), 0, _scale);
    }else
    {
        int aux = _number;
        int length = 0;
        while(aux > 0)
        {
            length++;
            aux /= 10;
        }
        aux = _number;
        pos.x += length * numbers.at(0)->model.at(0).size() * _scale;
        while(length > 0)
        {
            number = numbers.at(aux%10);
            DrawObject(&pos, number, 0, _scale);
            length--;
            aux /= 10;
            pos.x  -= number->model.at(0).size() * (_scale+1);
        }
    }
}
// **********************************************************************
//  void Draw ()
// Desenha todos os objetos do jogo na tela
// **********************************************************************
void Draw()
{
    int i;
    //Desenha Player
    DrawObject(player->coordinate, player->model,player->angle-90, player->model->sizePixel);
    //Desenha naves inimigas
    EnemyShip* enemy;
    for(i=0; i<enemysList.size(); i++)
    {
        enemy = enemysList.at(i);
        DrawObject(enemy->coordinate, enemy->model, enemy->angle, enemy->model->sizePixel);
    }
    //Desenha balas
    Bullet* bullet;
    for(i=0; i<bulletsInGame.size(); i++)
    {
        bullet = bulletsInGame.at(i);
        DrawObject(bullet->coordinate, bullet->model, bullet->angle, bullet->model->sizePixel);
    }
    //Desenha balas do Jogador
    for(i=0; i<player->bullets.size(); i++)
    {
        bullet = player->bullets.at(i);
        DrawObject(bullet->coordinate, bullet->model, bullet->angle, bullet->model->sizePixel);
    }

    //Desenha GUI
    DrawGUI();
    if(debug) Debug();
}
// **********************************************************************
//  void VerifyUserActions()
// Verifica quais a��es o jogado quer realizar com a nave
// **********************************************************************
void VerifyUserActions()
{
    if(GetKeyState('W') & 0x8000)
    {
        player->MoveShip(deltaTime);
    }

    if(GetKeyState('A') & 0x8000)
    {
        player->Rotate(false, deltaTime);
    }

    if(GetKeyState('D') & 0x8000)
    {
        player->Rotate(true, deltaTime);
    }
}
// **********************************************************************
// void LoadBestScore()
// Carrega best score do arquivo
// **********************************************************************
void LoadBestScore()
{
    ifstream file;

    file.open("BestScore.txt");

    if(!file)
    {
        printf("BestScore.txt nao encontrado!\n");
        return;
    }

    file >> bestScore;

    printf("BestScore.txt carregado com sucesso!\n");
    file.close();
}

// **********************************************************************
//  void LoadConfig()
// Carraga a quantidade de inimigos a ser combatido na partida, assim
// como a quantidade de modelos de naves e disparos
// **********************************************************************
void LoadConfig()
{
    ifstream file;

    file.open("Config.txt");
    if(!file)
    {
        printf("Config.txt nao encontrado!\n");
        return;
    }

    file >> WIDTHSCREEN;
    file >> HEIGHTSCREEN;
    file >> ENEMYAMOUNT;
    file >> ENEMYMODELS;
    file >> BULLETMODELS;

    printf("Config.txt carregado com sucesso!\n");
    file.close();
}

// **********************************************************************
//  bool IsColliding(Object* obj1, Object* obj2)
// Verifica a colis�o entre dois objetos
// **********************************************************************
bool IsColliding(Object* obj1, Object* obj2)
{
    if((obj2->coordinate->x + obj2->width) < obj1->coordinate->x) return false;
    if((obj2->coordinate->x - obj2->width) > obj1->coordinate->x) return false;
    if((obj2->coordinate->y + obj2->height) < obj1->coordinate->y) return false;
    if((obj2->coordinate->y - obj2->height) > obj1->coordinate->y) return false;
    return true;
}
// **********************************************************************
//  void InitializeVariables()
// Inicia as variaveis do jogo e instancia as naves inimigas
// **********************************************************************
void InitializeVariables()
{
    //Inicia variaveis do ambiente
    debug = false;
    score = 0;
    backgroundColor = colorsList.at(0);

    //Inicia a nave do jogador
    player = new PlayerShip(new Position(WIDTHSCREEN/2,HEIGHTSCREEN/2),playerModel, bulletModels.at(rand()%BULLETMODELS), WIDTHSCREEN, HEIGHTSCREEN);

    //Naves inimigas obrigatorias e Naves randomizadas
    enemysList.clear();
    for(int i=0; i<ENEMYAMOUNT; i++)
    {
        if(i < ENEMYMODELS) enemysList.push_back(new EnemyShip(player->coordinate, enemysModels.at(i), WIDTHSCREEN, HEIGHTSCREEN,bulletModels.at(rand()%BULLETMODELS), &bulletsInGame));
        else enemysList.push_back(new EnemyShip(player->coordinate, enemysModels.at(i%ENEMYMODELS), WIDTHSCREEN, HEIGHTSCREEN,bulletModels.at(rand()%BULLETMODELS), &bulletsInGame));
    }

    bulletsInGame.clear();
}
// **********************************************************************
//  void LoadColorsList()
// Carrega as cores do arquivo "colors.txt" que ser�o utilizadas nas
// naves
// **********************************************************************
void LoadColorsList()
{
    ifstream file;
    int temp;
    float r,g,b;

    file.open("colors.txt");

    if(!file)
    {
        printf("Erro ao ler o arquivo!");
        return;
    }

    file >> temp;

    while(file >> temp)
    {
        file >> r;
        file >> g;
        file >> b;
        colorsList.push_back(new ColorRGB(r/255,g/255,b/255));
    }

    file.close();
}
// **********************************************************************
//  void DrawGameOver()
// Desenha a tela de Game Over
// **********************************************************************
void DrawGameOver()
{
    DrawWord(textManager.gameOver);

    if(win) DrawWord(textManager.win);
    else DrawWord(textManager.lose);

    bestScore = (score > bestScore) ? score:bestScore;

    DrawWord(textManager.score);
    DrawNumber(score, new Position(550, 290), 4);
    DrawWord(textManager.bestScore);
    DrawNumber(bestScore, new Position(550, 250), 4);
    DrawWord(textManager.restart);
    DrawWord(textManager.quit);
}
// **********************************************************************
//  void LoadModel(ObjectModel* _modelObj, char fileName[])
// M�todo auxiliar para carregar os objetos modelo
// **********************************************************************
void LoadModel(ObjectModel* _modelObj, char fileName[])
{
    int x,y,line,column;
    ifstream file;

    file.open(fileName);
    if(!file)
    {
        fprintf(stderr,"%s nao encontrado!\n", fileName);
        return;
    }

    file >> y;
    file >> x;
    file >> _modelObj->sizePixel;

    for(line=0; line < y; line++)
    {
        vector<int> temp(x);
        for(column=0; column < x; column++)
        {
            file >> temp.at(column);
        }
        _modelObj->model.push_back(temp);
    }

    fprintf(stderr,"%s carregado com sucesso!\n", fileName);
    file.close();
}
// **********************************************************************
//  void LoadObjectsModels()
// Carrega os modelos dos arquivos txt
// **********************************************************************
void LoadObjectsModels()
{
    char fileName[1024];
    ObjectModel* enemyModel;
    ObjectModel* bulletModel;
    //Carrega todos os modelos das naves inimigas
    for(int currentEShip=1; currentEShip<=ENEMYMODELS; currentEShip++)
    {
        sprintf(fileName,"EShip%d.txt",currentEShip);
        enemyModel = new ObjectModel();
        LoadModel(enemyModel,fileName);
        enemysModels.push_back(enemyModel);
    }
    //Carrega todos os modelos de disparos
    for(int currentBullet=1; currentBullet<=BULLETMODELS; currentBullet++)
    {
        sprintf(fileName,"Bullet%d.txt",currentBullet);
        bulletModel = new ObjectModel();
        LoadModel(bulletModel,fileName);
        bulletModels.push_back(bulletModel);
    }
    playerModel = new ObjectModel();
    LoadModel(playerModel, "PShip.txt");
    heartModel = new ObjectModel();
    LoadModel(heartModel, "Heart.txt");
    //Le os modelos dos numeros
    LoadNumbersModels();
    //Le modelos do alfabeto
    LoadAlphabet();
    //Le best score;
    LoadBestScore();
}
// **********************************************************************
//  void DrawGUI()
// Desenha a interface do jogo
// **********************************************************************
void DrawGUI()
{
    glColor3f(1.0,0.0,0.0);
    Position* pos = new Position(20, HEIGHTSCREEN-20);
    int i, bulletCount;
    //Desenha as vidas do player
    for(i=0; i<player->health; i++)
    {
        DrawObject(pos,heartModel,0,heartModel->sizePixel);
        pos->x+=heartModel->model.at(0).size() * heartModel->sizePixel + 5;
    }

    pos->x = 15;
    pos->y = HEIGHTSCREEN - 50;
    bulletCount = 10 - player->bullets.size();
    glColor3f(1.0,1.0,1.0);
    //Desenha as balas disponiveis do jogador
    for(i=0; i<bulletCount; i++)
    {
        DrawObject(pos,player->bulletModel,0,3);
        pos->y-=15;
    }

    EnemyShip* enemy;
    pos->x = WIDTHSCREEN - 10;
    pos->y = 15;
    //Desenha as naves inimigas que ainda est�o vivas
    for(i=0; i<enemysList.size(); i++)
    {
        enemy = enemysList.at(i);
        DrawObject(pos,enemy->model, 90, 2);
        pos->x -= 30;
    }

    //Desenha Score
    DrawWord(textManager.scoreInGame);
    DrawNumber(score, new Position(740, 580), 2);
}
// **********************************************************************
//  void DrawQuad(int _ix, int _iy)
// M�todo auxiliar que desenha um quadrado
// **********************************************************************
void DrawQuad(float _ix, float _iy)
{
    glBegin(GL_QUADS);
    {
        glVertex2d(_ix,_iy);
        glVertex2d(_ix+1,_iy);
        glVertex2d(_ix+1,_iy+1);
        glVertex2d(_ix,_iy+1);
    }
    glEnd();
}
// **********************************************************************
//  void void DrawObject(Position* _pos, ObjectModel* _model, float _angle, float _sizeCell)
// Desenha um objeto especifico
// **********************************************************************
void DrawObject(Position* _pos, ObjectModel* _model, float _angle, float _sizeCell)
{
    int i,j;
    float x = _model->model.at(0).size();
    float y = _model->model.size();
    float currentX = x/-2.0;
    float currentY = y/-2.0;
    float baseX = currentX;
    ColorRGB* color;
    vector<int> temp;

    glPushMatrix();
    {
        glTranslatef(_pos->x - (x/2),_pos->y - (y/2),0);
        glScaled(_sizeCell,_sizeCell,1);
        glRotated(_angle,0,0,1);

        for(i=y-1; i>=0; i--)
        {
            temp = _model->model.at(i);
            for(j=0; j<x; j++)
            {
                color = colorsList.at(temp.at(j));
                if(color != backgroundColor)
                {
                    glColor3f(color->r,color->g, color->b);
                    DrawQuad(currentX,currentY);
                }
                currentX++;
            }
            currentY++;
            currentX = baseX;
        }

    }
    glPopMatrix();
}
// **********************************************************************
//  void Debug()
// Desenha algumas informa��es uteis na tela
// **********************************************************************
void Debug()
{
    EnemyShip* enemy;

    for(int i=0; i<enemysList.size(); i++)
    {
        enemy = enemysList.at(i);
        glColor3f(1.0,1.0,1.0);
        glBegin(GL_LINES);
        {
            glVertex2f(enemy->p0->x,enemy->p0->y);
            glVertex2f(enemy->p1->x,enemy->p1->y);
            glVertex2f(enemy->p1->x,enemy->p1->y);
            glVertex2f(enemy->p2->x,enemy->p2->y);
            glVertex2f(enemy->p2->x,enemy->p2->y);
            glVertex2f(enemy->p3->x,enemy->p3->y);
        }
        glEnd();
    }

    glPushMatrix();
    {
        glTranslated(player->coordinate->x,player->coordinate->y,0);
        glRotated(player->angle,0,0,1);
        glColor3f(1.0,1.0,1.0);
        glBegin(GL_LINES);
        {
            glVertex2d(-(WIDTHSCREEN/2),0);
            glVertex2d(WIDTHSCREEN/2,0);
            glVertex2d(0,HEIGHTSCREEN/2);
            glVertex2d(0,-(HEIGHTSCREEN/2));
        }
        glEnd();
    }
    glPopMatrix();


}
// **********************************************************************
//  void ClearObjects()
// Remove do jogo qualquer objeto que tenha o atributo "inGame" como false
// **********************************************************************
void ClearObjects()
{
    int i;
    EnemyShip* enemy;
    //Verifica se alguma nave inimiga n�o est� mais no jogo
    for(i=0; i<enemysList.size(); i++)
    {
        enemy = enemysList.at(i);
        if(!enemy->inGame) enemysList.erase(enemysList.begin()+i);
    }
    Bullet* bullet;
    //Verifica se alguma bala n�o est� no jogo
    for(i=0; i<bulletsInGame.size(); i++)
    {
        bullet = bulletsInGame.at(i);
        if(!bullet->inGame) bulletsInGame.erase(bulletsInGame.begin()+i);
    }
    //Verifica sem algum disparo n�o est� mais no jogo
    for(i=0; i<player->bullets.size(); i++)
    {
        if(!player->bullets.at(i)->inGame) player->bullets.erase(player->bullets.begin()+i);
    }
}
// **********************************************************************
//  void Process()
// Processa todas as a��es do objetos presentes no jogo
// **********************************************************************
void Process()
{
    //Verifica se o jogador esta no jogo
    if(!player->inGame)
    {
        state = GAMEOVER;
        win = false;
        return;
    }
    //verifica se o jogador ganhou
    if(enemysList.empty())
    {
        state = GAMEOVER;
        win = true;
        return;
    }
    //limpa ohjetos que n�o est�o mais no jogo
    ClearObjects();
    //verifica input do jogador
    VerifyUserActions();
    //Move todas as naves inimigas
    EnemyShip* enemy;
    for(int i=0; i<enemysList.size(); i++)
    {
        enemy = enemysList.at(i);
        enemy->MoveEShip(deltaTime);

        //Verifica colis�o da nave com o player
        if(IsColliding(player,enemy))
        {
            player->TakeDamage();
            enemy->inGame = false;
            return;
        }
        //Faz a nave inimiga disparar, caso seja possivel
        if(enemy->CanShoot()) enemy->Shoot();
    }
    //Move balas em jogo
    Bullet* bullet;
    for(int j=0; j<bulletsInGame.size(); j++)
    {
        bullet = bulletsInGame.at(j);
        bullet->MoveBullet(deltaTime);
        //Verifica colis�o do disparo inimigo com o player
        if(IsColliding(player,bullet))
        {
            player->TakeDamage();
            bullet->inGame = false;
            return;
        }
    }

    //Move todas as balas disparadas pelo player
    for(int i=0; i<player->bullets.size(); i++)
    {
        bullet = player->bullets.at(i);
        bullet->MoveBullet(deltaTime);

        //Verifica colis�o com todas as naves inimigas
        for(int j=0; j<enemysList.size(); j++)
        {
            enemy = enemysList.at(j);
            if(IsColliding(bullet,enemy))
            {
                enemy->inGame = false;
                bullet->inGame = false;
                score += enemy->value;
                break;
            }
        }
    }
}
// **********************************************************************
// void DrawWord(Text* _text)
// Desenha uma palavra na tela
// **********************************************************************
void DrawWord(Text* _text)
{
    int index,offset = 97;
    int token;
    bool caps = false;
    Position pos = *(_text->pos);
    ObjectModel* letter;

    for(index = 0; index < _text->length; index++)
    {
        token = _text->text[index];

        if(token == '/')
        {
            caps = !caps;
            continue;
        }

        if(token != ' ')
        {
            letter = letters.at(token - offset);
            if (caps)
            {
                DrawObject(&pos, letter, 0, _text->scale + 3);
                if(_text->text[index + 1] != '/') pos.x += letter->model.at(0).size() * _text->scale;
            }else
            {
                DrawObject(&pos, letter, 0, _text->scale);
            }
        }

        pos.x += letter->model.at(0).size() * _text->scale + 5;
    }
}
// **********************************************************************
// void LoadAlphabet()
// Carrega as letras do alfabeto
// **********************************************************************
void LoadAlphabet()
{
    ifstream file;
    char fileName[10];
    ObjectModel* letterModel;

    for(int i=97; i<123; i++)
    {
        sprintf(fileName,"%c.txt",i);

        file.open(fileName);

        if(file == NULL)
        {
            printf("%c.txt n�o encontrado!\n",i);
            return;
        }

        letterModel = new ObjectModel();
        LoadModel(letterModel, fileName);
        letters.push_back(letterModel);

        file.close();
    }
    printf("Alfabeto carregados com sucesso!\n");
}
// **********************************************************************
// void Quit()
// Salva o melhor score e finaliza o jogo
// **********************************************************************
void Quit()
{
    ofstream file;

    file.open("BestScore.txt");
    if(!file)
    {
        printf("BestScore.txt nao encontrado!\n");
        return;
    }

    file << bestScore;

    printf("BestScore salvo com sucesso!\n");
    file.close();

    exit( 0 );
}

// **********************************************************************
//  void main ( int argc, char** argv )
// **********************************************************************
int  main ( int argc, char** argv )
{
    LoadConfig();
    LoadColorsList();
    LoadObjectsModels();
    InitializeVariables();
    printf("Variaveis iniciadas\n");
    state = MENU;

    glutInit            ( &argc, argv );
    glutInitDisplayMode (GLUT_DOUBLE | GLUT_DEPTH | GLUT_RGB );
    glutInitWindowPosition (0,0);

    // Define o tamanho inicial da janela grafica do programa
    glutInitWindowSize  ( 650, 500);

    // Cria a janela na tela, definindo o nome da
    // que aparecera na barra de t�tulo da janela.
    glutCreateWindow    ( "Space Invaders OpenGL" );

    // executa algumas inicializa��es
    init ();

    // Define que o tratador de evento para
    // o redesenho da tela. A funcao "display"
    // ser� chamada automaticamente quando
    // for necess�rio redesenhar a janela
    glutDisplayFunc ( display );
    glutIdleFunc(animate);

    // Define que o tratador de evento para
    // o redimensionamento da janela. A funcao "reshape"
    // ser� chamada automaticamente quando
    // o usu�rio alterar o tamanho da janela
    glutReshapeFunc ( reshape );

    // Define que o tratador de evento para
    // as teclas. A funcao "keyboard"
    // ser� chamada automaticamente sempre
    // o usu�rio pressionar uma tecla comum
    glutKeyboardFunc ( keyboard );

    // Define que o tratador de evento para
    // as teclas especiais(F1, F2,... ALT-A,
    // ALT-B, Teclas de Seta, ...).
    // A funcao "arrow_keys" ser� chamada
    // automaticamente sempre o usu�rio
    // pressionar uma tecla especial
    glutSpecialFunc ( arrow_keys );

    // inicia o tratamento dos eventos
    glutMainLoop ( );

    return 0;
}
