#include "ObjectModel.h"
#include <stdio.h>
#include <vector>
// **********************************************************************
// ObjectModel()
// Desconstrutor da classe ObjectModel
// **********************************************************************
ObjectModel::ObjectModel()
{
    sizePixel = 1.0;
}
// **********************************************************************
// ~ObjectModel()
// Construtor da classe ObjectModel
// **********************************************************************
ObjectModel::~ObjectModel()
{
}
