#include "ColorRGB.h"
// **********************************************************************
// ColorRGB(float _r, float _g, float _b)
// Construtor da Classe ColorRGB
// **********************************************************************
ColorRGB::ColorRGB(float _r, float _g, float _b)
{
    r = _r;
    g = _g;
    b = _b;
}
// **********************************************************************
// ~ColorRGB()
// Construtor da Classe ColorRGB
// **********************************************************************
ColorRGB::~ColorRGB()
{

}
