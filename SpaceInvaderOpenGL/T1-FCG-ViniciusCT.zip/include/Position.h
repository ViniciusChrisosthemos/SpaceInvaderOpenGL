#ifndef POINT_H
#define POINT_H


class Position
{
    public:
        float x;
        float y;

        Position();
        Position(float _x, float _y);
        virtual ~Position();

    protected:

    private:
};

#endif // POINT_H
