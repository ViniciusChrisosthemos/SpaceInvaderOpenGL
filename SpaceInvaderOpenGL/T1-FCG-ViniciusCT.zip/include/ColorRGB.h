#ifndef COLORRGB_H
#define COLORRGB_H


class ColorRGB
{
    public:
        float r;
        float g;
        float b;

        ColorRGB(float _r,float _g,float _b);
        virtual ~ColorRGB();

    protected:

    private:
};

#endif // COLORRGB_H
